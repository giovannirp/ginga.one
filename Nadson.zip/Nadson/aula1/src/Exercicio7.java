
public class Exercicio7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int m = 1;
		int x = m--;
			for (int n = 0; n <=10; n++){
			m = n + 1 ;
			
			System.out.println(m);
		
		
	

	   }

	}

}
