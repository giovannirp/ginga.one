
public class Exercicio5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fatorial = 1;
		for (int n = 1; n <=40; n++){
			fatorial *= n;
			
			System.out.println("fatoria de " + n + " = " + fatorial);
		
		
	

	   }
		
	}

}
