
public class Exercio2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		for(int i = 250; i <= 400; i++ ){
			System.out.println(i);
			}

	}

}
