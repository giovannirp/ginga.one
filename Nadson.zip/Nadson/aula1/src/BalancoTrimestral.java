
public class BalancoTrimestral {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int gastosJaneiro = 15000;
		int gastosFeveiro = 23000;
		int gastosMarco = 17000;
		
		int gastosTrimestre = gastosJaneiro + gastosFeveiro + gastosMarco;
		
		System.out.println("O total � " + gastosTrimestre);
		
		
				

	}

}
