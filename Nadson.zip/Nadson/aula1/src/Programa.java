
public class Programa {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// criando a conta
		Conta minhaConta;
		minhaConta = new Conta( );
		
		minhaConta.nome =  "Nadson";
		minhaConta.saldo = 10000;
		
		minhaConta.sacar(400);
		
		minhaConta.deposita(800);
		
		System.out.println(minhaConta.saldo);

		
		
	}

}
