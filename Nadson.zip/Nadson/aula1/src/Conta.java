
public class Conta {

	int numero;
	double saldo;
	double limite;
	String nome;
	
	boolean sacar ( double valor){
		if (this.saldo < valor){
			return false;
		}
		this.saldo -= valor;
		return true;
				
				
	}
	
	void deposita( double valor){
		
		this.saldo += valor;
		
	}
	
	
		boolean tranferencia (double valor, Conta destino){
			if (!this.sacar(valor)){
				return	false;
							
			}
			
			destino.deposita (valor);
			return true;
				
		}
		
	

}
