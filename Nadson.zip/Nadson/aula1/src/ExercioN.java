
public class ExercioN {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	
		
		int fatorial = 1;
		for (int n = 1; n <=10; n++){
			fatorial *= n;
			
			System.out.println("fatoria de " + n + " = " + fatorial);
		
		
	

	   }
	
	}
	
	
}
