
public class Exercicio4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//multiplos de 3
		for (int i = 0; i <= 100; i ++) {
			if (i % 3 == 0) {
				System.out.println(i);	
			}
		}

	}

}
